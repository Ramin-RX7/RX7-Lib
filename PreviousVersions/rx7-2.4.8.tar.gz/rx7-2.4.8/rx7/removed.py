

class File:
    '''
    (CLASS METHODS)
    Actions and Information about files and directories.
    (READ METHODS DOCSTRING)
     if path exists:
         --  self.size - self.abspath - self.acstime - self.mdftime
     if path type is file:
         --  self.content
     if path type is directory:
         --  self.MEMBERS.LIST group (7 Attributes)  with high API (self.MEMBERS.TYPE_PATH)

     METHODS: 
     - copy
     - move
     - rename
     - hide
     - delete
     - read_only
    '''
    def __init__(self,path):
        self.path=    path
        self.live_path= path
        self.size=    None
        self.abspath= None
        self.acstime= None
        self.mdftime= None
        #self.content= None
        if files.exists(path):
            self.size= files.size(path)
            self.abspath= files.abspath(path)
            self.acstime= files.acstime(path)
            self.mdftime= files.mdftime(path)
            #if __import__('platform').system()=='Windows':
            self.hidden= files.is_hidden(path)
            if os.path.isfile(path):
                self.type= 'file'
                self.content= files.read(path)
                if __import__('platform').system()=='Windows':
                 self.readonly= files.is_readonly(path)
                else: self.readonly= 'UNKNOWN'
                self.basename= os.path.basename(path).split('.')
                try: self.ext= self.basename[1]
                except: self.ext= None
             
            if os.path.isdir(path):
                self.type='dir'                
                #walk= os.walk(path)

                class __MMEMBERS:
                    def __init__(self,all_exactdir,all_all_sep,files_exactdir,files_all,files_all_sep,dirs_exactdir,dirs_all):
                        self.all_exactdir= all_exactdir
                        self.all_all_sep= all_all_sep
                        self.files_exactdir= files_exactdir
                        self.files_all= files_all
                        self.files_all_sep= files_all_sep
                        self.dirs_exactdir= dirs_exactdir
                        self.dirs_all= dirs_all

                self.MEMBERS= __MMEMBERS(
                    os.listdir(path),
                    [i for i in os.walk(path)],                 
                    [i for i in os.walk(path)][0][2],
                    [val for sublist in [[os.path.join(i[0], j) for j in i[2]] for i in os.walk(path)] for val in sublist],
                    [[os.path.join(i[0], j) for j in i[2]] for i in os.walk(path)],
                    sorted([i for i in os.listdir(path) if i not in [i for i in os.walk(path)][0][2]]),
                    [TPL[0] for TPL in [i for i in os.walk(path)]])

                self.tree= File.__tree2(self.path)
                self.tree_dirs= File.__tree2(self.path,limit_to_directories=True)

             
    def delete(self):
        '''
        Use this to delete  self.
        '''
        files.remove(self.path)
    def rename(self,new_name):
        '''
        Rename self with this function.
        '''
        os.rename(self.path,new_name)
    def move(self,dst):
        '''
        Move (cut) self from crs to dst.
        '''
        shutil.move(self.path,dst)
        self.live_path= dst
        #Baraye folder hast ya na?
    def copy(self,dst):
        '''
        Copy the file from src to destination.
        (You can use it instead of rename too.
         e.g:
            copy('D:\\Test.py','E:\\New.py')
            (It copies Test.py to E drive and renames it to New.py)
         )
        '''
        files.copy(self.path,dst)
    def hide(self,mode=True):
        '''
        Hide file or folder.
        If mode==False: makes 'not hide'
        '''
        files.hide(self.path,mode)
    def read_only(self,mode=True):
        '''
        Make file attribute read_only.
        If mode==False: makes 'not read_only'
        '''
        files.read_only(self.path,mode)

    @staticmethod
    def __tree2(path, level: int=-1, limit_to_directories: bool=False,
            length_limit: int=1000, print_info: bool=True):
        """Given a directory Path object print a visual tree structure"""
        from pathlib import Path
        from itertools import islice
        space =  '    '; branch = '│   '; tee =    '├── '; last =   '└── '
        #dir_path= self.path
        dir_path= path
        dir_path = Path(dir_path) # accept string coerceable to Path
        files = 0
        directories = 0
        def inner(dir_path: Path, prefix: str='', level=-1):
            nonlocal files, directories
            if not level:  return # 0, stop iterating
            if limit_to_directories: contents = [d for d in dir_path.iterdir() if d.is_dir()]
            else:  contents = list(dir_path.iterdir())
            pointers = [tee] * (len(contents) - 1) + [last]
            for pointer, path in zip(pointers, contents):
                if path.is_dir():
                    yield prefix + pointer + path.name
                    directories += 1
                    extension = branch if pointer == tee else space 
                    yield from inner(path, prefix=prefix+extension, level=level-1)
                elif not limit_to_directories:
                    yield prefix + pointer + path.name
                    files += 1
        RETURN=''
        RETURN+=dir_path.name+'\n'
        iterator = inner(dir_path, level=level)
        for line in islice(iterator, length_limit): RETURN+=line+'\n'
        if next(iterator, None): RETURN+=f'... length_limit, {length_limit}, reached, counted:'
        if print_info: RETURN+=f'\n{directories} directories' + (f', {files} files' if files else '')
        return RETURN

# file table html
'''
 <h3>&nbsp; &nbsp; object File:<strong>&nbsp;</strong><em>Actions and information about files.</em></h3>
 <table style="height: 653px; margin-left: 45px;" width="545" cellpadding="5px">
 <tbody>
 <tr>
 <td style="width: 193px;">__init__(self,path)</td>
 <td style="width: 357px;">Creating file object.</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.size</td>
 <td style="width: 357px;">
 <div>
 <div>size&nbsp;of&nbsp;the&nbsp;file&nbsp;in&nbsp;byte(s).&nbsp;Also&nbsp;work&nbsp;on&nbsp;directories.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.abspath</td>
 <td style="width: 357px;">
 <div>
 <div>Return&nbsp;absolute&nbsp;path&nbsp;of&nbsp;given&nbsp;path.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.exists</td>
 <td style="width: 357px;">Return Boolean. If exists True, else: False</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.mdftime</td>
 <td style="width: 357px;">
 <div>
 <div>Get&nbsp;last&nbsp;modify&nbsp;time&nbsp;of&nbsp;the&nbsp;file.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.acstime</td>
 <td style="width: 357px;">
 <div>
 <div>Get&nbsp;last&nbsp;access&nbsp;time&nbsp;of&nbsp;the&nbsp;file.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.type</td>
 <td style="width: 357px;">
 <div>
 <div>'file' for files and 'dir' for directories.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.delete()</td>
 <td style="width: 357px;">
 <div>
 <div>Use&nbsp;this&nbsp;to&nbsp;delete file or folder.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.rename(new_name)</td>
 <td style="width: 357px;">
 <div>
 <div>Rename&nbsp;file with&nbsp;this&nbsp;method.</div>
 </div>
 </td>
 </tr>
 <tr>
 <td style="width: 193px;">self.move(dst)</td>
 <td style="width: 357px;">Move file from path to dst. (Read Doc String of copy func)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.copy(dst)</td>
 <td style="width: 357px;">Copy file from self.path to dst. (Also you can use it as rename)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.hide(path)</td>
 <td style="width: 357px;">Hide given path. (It can be file or directory.)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.read_only(mode=True)</td>
 <td style="width: 357px;">Make file or folder read-only. (Read Doc String)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.content&nbsp;&nbsp;(only for files)</td>
 <td style="width: 357px;">If self.type=='file': content is files.read(self.path)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.basename&nbsp;&nbsp;(only for files)</td>
 <td style="width: 357px;">Basename of file (e.g: C:/Users/file.txt ==&gt; file.txt)&nbsp;</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.ext&nbsp;&nbsp;(only for files)</td>
 <td style="width: 357px;">Returns File extension if it has else None</td>
 </tr>
 <tr>
 <td style="width: 193px;">&nbsp;</td>
 <td style="width: 357px;">&nbsp;</td>
 </tr>
 <tr>
 <td style="width: 193px;">&nbsp; &nbsp;&nbsp;<strong>if self.path is dir</strong></td>
 <td style="width: 357px;">&nbsp;</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.tree</td>
 <td style="width: 357px;">String which presents visual tree from path to the end.</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.tree_dirs</td>
 <td style="width: 357px;">String which presents visual tree from path to the end. (Only directories)</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.MEMBERS.
 <div>
 <div><strong>all</strong>_<strong>exactdir</strong></div>
 </div>
 </td>
 <td style="width: 357px;">List of <strong>all</strong>&nbsp;things those are in <strong>exact directory</strong></td>
 </tr>
 <tr>
 <td style="width: 193px;">
 <div>
 <div>self.MEMBERS.<strong>files</strong>_<strong>exactdir</strong></div>
 </div>
 </td>
 <td style="width: 357px;">List of <strong>files</strong> which are in <strong>exact directory</strong></td>
 </tr>
 <tr>
 <td style="width: 193px;">
 <div>
 <div>
 <div>
 <div>self.MEMBERS.<strong>dirs</strong>_<strong>exactdir</strong></div>
 </div>
 </div>
 </div>
 </td>
 <td style="width: 357px;">List of <strong>dirs</strong>&nbsp; which are in <strong>exact directory</strong></td>
 </tr>
 <tr>
 <td style="width: 193px;">self.MEMBERS.<strong>files</strong>_<strong>all</strong></td>
 <td style="width: 357px;">List of <strong>files</strong>&nbsp;which are in <strong>exact directory </strong>and<strong> all sub-directories</strong></td>
 </tr>
 <tr>
 <td style="width: 193px;">
 <div>
 <div>
 <div>
 <div>self.MEMBERS.
 <div>
 <div><strong>files</strong>_<strong>all</strong>_<strong>sep</strong></div>
 </div>
 </div>
 </div>
 </div>
 </div>
 </td>
 <td style="width: 357px;">List of <strong>files</strong>&nbsp;which are in <strong>exact directory </strong>and<strong> all sub-directories&nbsp;</strong>seprated by their directories</td>
 </tr>
 <tr>
 <td style="width: 193px;">
 <div>
 <div>
 <div>
 <div>self.MEMBERS.<strong>dirs</strong>_<strong>all</strong></div>
 </div>
 </div>
 </div>
 </td>
 <td style="width: 357px;">List of&nbsp;<strong>directories</strong> (<strong>Exact dir</strong> and <strong>all sub-dirs</strong>)&nbsp;</td>
 </tr>
 <tr>
 <td style="width: 193px;">self.MEMBERS.<strong>all_all_sep</strong></td>
 <td style="width: 357px;">List&nbsp; of <strong>all</strong> things in path (<strong>exact dir &amp; sub-dirs</strong>)</td>
 </tr>
 </tbody>
 </table>
 <p>&nbsp;</p>
'''